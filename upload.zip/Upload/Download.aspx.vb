Imports System.Data.SqlClient

Public Class Download
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

		Dim iFileId As Integer = Request.QueryString("id")
		Dim cn As New System.Data.SqlClient.SqlConnection(GetConnectionString())
		cn.Open()

		Dim sSql As String = "SELECT FileData, FileName, FileContentType, FileSize FROM AppFile WHERE FileId = " & iFileId
		Dim cmd As New SqlCommand(sSql, cn)
		Dim dr As SqlDataReader = cmd.ExecuteReader(Data.CommandBehavior.CloseConnection)
		If dr.Read() Then

			Dim sFileContentType As String = dr.GetValue(dr.GetOrdinal("FileContentType")) & ""
			Dim sFileName As String = dr.GetValue(dr.GetOrdinal("FileName")) & ""

			'Response.AddHeader("content-disposition", "inline;filename=" & PadFileName(sFileName))
			Response.AddHeader("content-disposition", "attachment; filename=" & PadFileName(sFileName))
			Response.ContentType = sFileContentType


			Dim iBufferSize As Integer = 1000
			Dim oBuffer(iBufferSize - 1) As Byte
			Dim iByteCount As Long	 'The bytes returned from GetBytes.
			Dim iStartIndex As Long = 0	 'The starting position in the BLOB output

			iByteCount = dr.GetBytes(dr.GetOrdinal("FileData"), iStartIndex, oBuffer, 0, iBufferSize)
			If iByteCount > 0 Then
				'Continue reading and writing while there are bytes beyond the size of the buffer.
				While (iByteCount = iBufferSize)
					Response.BinaryWrite(oBuffer)
					iStartIndex += iBufferSize
					iByteCount = dr.GetBytes(dr.GetOrdinal("FileData"), iStartIndex, oBuffer, 0, iBufferSize)
				End While

				If iByteCount > 2 Then
					ReDim Preserve oBuffer(iByteCount - 2)
					Response.BinaryWrite(oBuffer)
				End If
			End If
		End If

		dr.Close()

	End Sub

	Private Function GetConnectionString() As String
		Return System.Configuration.ConfigurationManager.AppSettings("ConnectionString")
	End Function

	Private Function PadFileName(ByVal sReportName As String) As String
		Return Server.UrlEncode(Trim(PadFileName2(sReportName)))
	End Function

	Private Function PadFileName2(ByVal s As String) As String
		s = Replace(s, "<", "")
		s = Replace(s, ">", "")
		s = Replace(s, ":", "-")
		s = Replace(s, """", "")
		s = Replace(s, "/", "")
		s = Replace(s, "\", "")
		s = Replace(s, "?", "")
		s = Replace(s, " ", "_")
		Return Replace(s, "*", "")
	End Function

End Class